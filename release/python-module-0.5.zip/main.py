from libs import main

default_time=20
mod_ip="172.30.1.77"
mod_port=502
mod_word=0
txt_path="test/info.txt"
interval=1

main.main(default_time,mod_ip,mod_port,mod_word,txt_path,interval)