from libs import main
main.main()